"""
Author: Mingjian He <mh105@mit.edu>

multitaper module contains multitaper spectrogram computation used in SOMATA
"""

from .fast_psd_multitaper import fast_psd_multitaper
